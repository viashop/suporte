<!-- #page-header -->
<section id="page-header" class="clearfix">
<div class="ht-container">

	<h1 id="page-header-title"><?php the_title(); ?></h1>

</div>
</section>
<!-- /#page-header -->