<?php if ( is_active_sidebar( 'ht_sidebar_kb' ) ) { ?>

<!-- #sidebar -->
<aside id="sidebar" role="complementary" itemtype="http://schema.org/WPSideBar" itemscope="itemscope">
	<?php dynamic_sidebar( 'ht_sidebar_kb' );?>
</aside>
<!-- /#sidebar -->

<?php } ?>