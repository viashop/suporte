<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?>>
	<h3 class="entry-title" itemprop="headline">
		<a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
	</h3>
</article>